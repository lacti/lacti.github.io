﻿namespace DistWork.Core
{
    public class SocketInformation
    {
        public static readonly SocketInformation Invalid = new SocketInformation();
    }
}